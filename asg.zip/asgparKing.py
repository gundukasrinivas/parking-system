from tkinter import *
from tkinter import ttk 
import time
import datetime
import sqlite3

main=Tk()
main.title("Parking Management System")
main.geometry("1366x768")
main.configure(bg="#c7c5fa")


globals()
#--------------------variable---------------

FNAME=StringVar()
LNAME=StringVar()
GENDER=StringVar()
AGE=StringVar()
ADDRESS=StringVar()
AADHAR=StringVar()
MOBILE=StringVar()
UNAME=StringVar()
PASS=StringVar()
LOGU=StringVar()
LOGP=StringVar()
VNAME=StringVar()
VREGNO=StringVar()
var = IntVar()
VMOB=StringVar()
VUSER=StringVar()




def database():

    conn = sqlite3.connect('pm.db')
    cur=conn.cursor()

    cur.execute('''CREATE TABLE IF NOT EXISTS 'USER' 
             (USER_ID       INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
             FIRSTNAME      TEXT    NOT NULL,
             LASTTNAME      TEXT    NOT NULL,
             GENDER         TEXT,
             AGE            INT     NOT NULL,
             ADDRESS        VARCHAR(50),
             AADHAR_NO      INT(16),
             MOBILE_NO      INT(10),
             USERNAME       VARCHAR2,
             PASSWOARD      VARCHAR2);''')

    conn.close()



def database_vechile():
    conn = sqlite3.connect('pm.db')
    cur=conn.cursor()

    cur.execute('''CREATE TABLE IF NOT EXISTS 'VEHICLE' 
             (V_ID      INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
             V_NAME        TEXT    NOT NULL,
             V_REG_NO      TEXT    NOT NULL,
             V_TYPE_W      TEXT,
             V_MOB         INT,
             VUSER         TEXT    NOT NULL
             
             
             )
             ;''')

    conn.close()





def v_insert():
    if  VNAME.get() == "" or VREGNO.get() == "" or var.get() == "" or VMOB.get() == "" or VUSER.get() =="":

        lbl.config(text="Please complete the required field!", fg="red",bg='white')




    else:
        database_vechile()
        conn = sqlite3.connect("pm.db")
        cur = conn.cursor()

        cur.execute("INSERT INTO VEHICLE (V_NAME,V_REG_NO,V_TYPE_W,V_MOB,VUSER) \
                   VALUES(?,?,?,?,?)", (str(VNAME.get()), str(VREGNO.get()), str(var.get()), str(VMOB.get()),str(VUSER.get())))




        conn.commit()
        VNAME.set("")
        VREGNO.set("")
        var.set("")
        VMOB.set("")
        VUSER.set("")
        cur.close()
        conn.close()
        lbl.config(text="--------Successfully Added----------", fg="green",bg='white')



def admin_log_screen():
    print("Successfully Login")
    global Home
    main.withdraw()
    Home = Toplevel()
    Home.geometry("1366x768")
    Home.configure(bg='#2c475c')
    a1 = Frame(Home, width=1366, height=700, bd=5, relief="flat", bg="white")
    a1.pack(padx=0, pady=70)
    b4 = Button(Home, text="BACK", height=3, width=20, bg="#2c475c", fg="white", command=main.deiconify)
    b4.place(x=1, y=4)
    b5= Button(Home, text="UREAD", height=3, width=20, bg="#2c475c", fg="white", command=read)
    b5.place(x=10, y=560)
    b6 = Button(Home, text="VREAD", height=3, width=20, bg="#2c475c", fg="white", command=read1)
    b6.place(x=10, y=500)




def read():

    conn = sqlite3.connect('pm.db')
    cur=conn.cursor()

    cursor = cur.execute("SELECT * from USER")
    fv11 = LabelFrame(Home, text="User Table", fg='white', bg='#2c475c', font=('arial', 14))
    fv11.place(x=10, y=80)
    fv11.configure(bg='#2c475c')

    fv1=Label(fv11,bg='#2c475c')
    fv1.pack(anchor=CENTER, pady=50, padx=20)


    for index,row in enumerate(cursor):


        Label(fv1, text='ID:' , fg='white', bg='#2c475c').grid(row=0, column=0)
        Label(fv1, text='Name:', fg='white', bg='#2c475c').grid(row=0, column=1)
        Label(fv1, text='Gender:', fg='white', bg='#2c475c').grid(row=0, column=2)
        Label(fv1, text='Age:', fg='white', bg='#2c475c').grid(row=0, column=3)
        Label(fv1, text='Address:'  , fg='white', bg='#2c475c').grid(row=0, column=4)
        Label(fv1, text='Aadhar:' , fg='white', bg='#2c475c').grid(row=0, column=5)
        Label(fv1, text='Mobile', fg='white', bg='#2c475c').grid(row=0, column=6)
        Label(fv1, text='User', fg='white', bg='#2c475c').grid(row=0, column=7)


        Label(fv1, text="" + str(row[0]), fg='white', bg='#2c475c').grid(row=index + 1, column=0)
        Label(fv1, text="" + str(row[1])+" "+str(row[2]), fg='white', bg='#2c475c').grid(row=index + 1, column=1)
        Label(fv1, text="" + str(row[3]), fg='white', bg='#2c475c').grid(row=index + 1, column=2)
        Label(fv1, text="" + str(row[4]), fg='white', bg='#2c475c').grid(row=index + 1, column=3)
        Label(fv1, text="" + str(row[5]), fg='white', bg='#2c475c').grid(row=index + 1, column=4)
        Label(fv1, text="" + str(row[6]), fg='white', bg='#2c475c').grid(row=index + 1, column=5)
        Label(fv1, text="" + str(row[7]), fg='white', bg='#2c475c').grid(row=index + 1, column=6)
        Label(fv1, text="" + str(row[8]), fg='white', bg='#2c475c').grid(row=index + 1, column=7)




    cursor.close()
    conn.close()

def read1():
    conn = sqlite3.connect('pm.db')
    cur=conn.cursor()
    cursor = cur.execute("SELECT * from VEHICLE")
    fv11 = LabelFrame(Home, text="Vehicle Table", fg='white', bg='#2c475c', font=('arial', 14))
    fv11.place(x=1000, y=80)
    fv11.configure(bg='#2c475c')
    for index, row in enumerate(cursor):
        Label(fv11, text='ID:' ,fg='white', bg='#2c475c').grid(row=0, column=7)
        Label(fv11, text='Name:', fg='white', bg='#2c475c').grid(row= 0,
                                                                               column=8)
        Label(fv11, text='Vehicle Reg:' , fg='white', bg='#2c475c').grid(row=0, column=9)
        Label(fv11, text='User:' , fg='white', bg='#2c475c').grid(row= 0, column=10)

        Label(fv11, text=""+ str(row[0]), fg='white', bg='#2c475c').grid(row=index + 1, column=7)
        Label(fv11, text=""+ str(row[1]), fg='white', bg='#2c475c').grid(row=index + 1,
                                                                                                   column=8)
        Label(fv11,text=""+str(row[2]), fg='white', bg='#2c475c').grid(row=index + 1, column=9)
        Label(fv11,text=""+  str(row[5]), fg='white', bg='#2c475c').grid(row=index + 1, column=10)


    conn.close()


def login_screen():
    print("Successfully Login")
    main.withdraw()
    Home = Toplevel()
    Home.geometry("1366x768")
    Home.configure(bg="#2c475c")
    l1 = Frame(Home, width=1366, height=700, bd=5, relief="flat", bg="white")
    l1.pack(padx=0, pady=70)


     #------------------Label---------------


    l9 = Label(Home,text="Username", font=('arial', 12), bg='white', fg='#2c475c')
    l9.place(x=565, y=220)

    l10 = Label(Home,text="Password", font=('arial', 12), bg='white', fg='#2c475c')
    l10.place(x=565, y=260)

    #-------------Entry------------------

    e10 = Entry(Home, width=28, textvariable=LOGU)
    e10.place(x=660, y=220)

    e11 = Entry(Home, show="*", width=28, textvariable=LOGP)
    e11.place(x=660, y=260)

    #--------------button-----------------
    b3 = Button(Home, text="Submit", height=1, width=10, bg="#2c475c", fg="white",command=login)
    b3.place(x=700, y=300)

    b4 = Button(Home, text="BACK", height=3, width=20, bg="#2c475c", fg="white",command=main.deiconify)
    b4.place(x=1, y=4)

    global t2
    t2 = Label(Home,bg='white')
    t2.place(x=650, y=200)



def login():

    if LOGU.get() == "" or LOGP.get() == "":
        t2.config(text="Please complete the required field!", fg="red",bg='white')
    else:
        conn = sqlite3.connect('pm.db')
        cur = conn.cursor()
        cur.execute("SELECT * FROM `USER` WHERE `USERNAME` = ? AND `PASSWOARD` = ?", (str(LOGU.get()),str(LOGP.get())))
        if cur.fetchone() is not None:
            print("Welcome")

            screen(str(LOGU.get()))
            LOGU.set("")
            LOGP.set("")
            t2.config(text="")
        else:
             print("Invalid login!Try again")
             t2.config(text="Invalid username or password", fg="red",bg='white')
             LOGU.set("")
             LOGP.set("")
        cur.close()
        conn.close()



def screen(username):
    global Home
    main.withdraw()
    Home = Toplevel()
    Home.geometry("1366x768")
    Home.configure(bg='#2c475c')
    a1 = Frame(Home, width=1366, height=700, bd=5, relief="flat", bg="white")
    a1.pack(padx=0, pady=70)


    b5 = Button(Home, text="LOGOUT", height=3, width=26, bg="#2c475c", fg="white", command=Home.destroy)
    b5.place(x=1125, y=4)
    b6 = Button(Home, text="ADD VEHICLE ", height=3, width=27, bg="#2c475c", fg="white",command=vehicle_del)
    b6.place(x=1120, y=515)
    b7 = Button(Home, text="PARKING", height=3, width=27, bg="#2c475c", fg="white", command=parking_near)
    b7.place(x=1120, y=575)

    b8 = Button(Home, text="UPDATE", height=3, width=27, bg="#2c475c", fg="white" ,command=vehicle_del)
    b8.place(x=850, y=575)


    p11 = LabelFrame(Home, text="Price chart for Parking", fg='white', bg='#2c475c', font=('arial', 14), padx=20,
                     pady=30)
    p11.place(x=1120, y=80)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="For 1 hr       = Rs 15",fg='white', bg='#2c475c').pack()
    Label(p1, text="For 2 hr       = Rs 25",fg='white', bg='#2c475c').pack()
    Label(p1, text="For 5 hr       = Rs 70",fg='white', bg='#2c475c').pack()
    Label(p1, text="For 1 Month    = Rs 6000",fg='white', bg='#2c475c').pack()




    conn = sqlite3.connect('pm.db')
    cur = conn.cursor()
    test = cur.execute("SELECT firstname,lasttname ,address,aadhar_no,mobile_no FROM `USER` WHERE `USERNAME`= ?", (username,))
    if test:
        print('Working fine')
        for row in test:

            fv11 = LabelFrame(Home, text="User Profile", fg='white', bg='#2c475c',font=('arial', 14),padx=35, pady=30)
            fv11.place(x=10, y=80)
            fv11.configure(bg='#2c475c')

            fv1 = Label(fv11)
            fv1.pack(anchor=CENTER, pady=50, padx=20)
            fv1.configure(bg='#2c475c')



            Label(Home,text='Welcome '+ row[0]+" !",font=('arial', 16),fg='white',bg='#2c475c').place(x=600,y=6)
            Label(fv1, text=' Name   :' + row[0]+" "+row[1],fg='white',bg='#2c475c',font=('arial', 12)).pack()
            Label(fv1,text='Address :' + row[2] ,fg='white',bg='#2c475c',font=('arial', 12)).pack()
            Label(fv1, text=' Aadhar :' +str( row[3]), fg='white', bg='#2c475c',font=('arial', 12)).pack()
            Label(fv1, text=' Mobile :' +str(row[4]), fg='white', bg='#2c475c',font=('arial', 12)).pack()

    else:
        print('Something went wrong')

    cur.close()
    conn.close()


    conn = sqlite3.connect('pm.db')
    cur = conn.cursor()
    test = cur.execute("SELECT V_ID,V_NAME,V_REG_NO,V_TYPE_W FROM `VEHICLE` WHERE `VUSER`= ?",
                       (username,))
    f11 = LabelFrame(Home, text="Vehicle Details", fg='white', bg='#2c475c', font=('arial', 14), padx=35, pady=20)
    f11.place(x=10, y=380)
    f11.configure(bg='#2c475c')

    h1 = Label(f11)
    h1.pack()
    h1.configure(bg='#2c475c')

    if test:
        print('Working fine')
        for index, row in enumerate(test):
            Label(h1, text='Vehicle Id  ', font=('arial', 14), fg='white', bg='#2c475c').grid(row=0, column=1)
            Label(h1, text='Vehicle Name  ', font=('arial', 14), fg='white', bg='#2c475c').grid(row=0, column=2)
            Label(h1, text='Vehicle Reg  ', font=('arial', 14), fg='white', bg='#2c475c').grid(row=0, column=3)

            Label(h1, text='' + str(row[0]) , font=('arial', 12), fg='white', bg='#2c475c').grid(row=index+1,column=1)
            Label(h1, text='' + row[1] , fg='white', bg='#2c475c', font=('arial', 12)).grid(row=index+1,column=2)
            Label(h1, text='' + str(row[2]), fg='white', bg='#2c475c', font=('arial', 12)).grid(row=index+1,column=3)


    else:
        print('Something went wrong')

    cur.close()
    conn.close()


def parking_near():

    fv11 = LabelFrame(Home, text="Parking Near you", fg='white', bg='#2c475c')
    fv11.place(x=500, y=80)
    fv11.configure(bg='#2c475c')

    fv1 = Label(fv11)
    fv1.pack(anchor=CENTER, pady=50,padx=80)
    fv1.configure(bg='#2c475c')

    bk1 = Button(fv1, text="BLOCK1", height=1, width=8, bg="#2c475c", fg="white",command=block)
    bk1.pack( padx=13, pady=10)

    bk2= Button(fv1, text="BLOCK2", height=1, width=8, bg="#2c475c", fg="white",command=block1)
    bk2.pack( padx=13, pady=10)

    bk3 = Button(fv1, text="BLOCK3", height=1, width=8, bg="#2c475c", fg="white",command=block2)
    bk3.pack( padx=13, pady=10)

    bk4 = Button(fv1, text="BLOCK4", height=1, width=8, bg="#2c475c", fg="white",command=block3)
    bk4.pack( padx=13, pady=10)

    bk5 = Button(fv1, text="BLOCK5", height=1, width=8, bg="#2c475c", fg="white",command=block4)
    bk5.pack( padx=13, pady=10)

    bk6 = Button(fv1, text="BLOCK6", height=1, width=8, bg="#2c475c", fg="white",command=block5)
    bk6.pack(padx=13, pady=10)

    v1 = Button(fv1, text="CANCEL", height=1, width=8, bg="#2c475c", fg="white", command=fv11.destroy)
    v1.pack(padx=13, pady=10)



def block():
    p11 = LabelFrame(Home, text="Block1", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =10", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =7", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 8082205783 ", fg='white', bg='#2c475c').pack()


def block1():
    p11 = LabelFrame(Home, text="Block2", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =10", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =1", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 9622243312 ", fg='white', bg='#2c475c').pack()


def block2():
    p11 = LabelFrame(Home, text="Block3", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =15", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =10", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 9398335652 ", fg='white', bg='#2c475c').pack()


def block3():
    p11 = LabelFrame(Home, text="Block4", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =10", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =3", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 7895588744 ", fg='white', bg='#2c475c').pack()

def block4():
    p11 = LabelFrame(Home, text="Block5", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =20", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =2", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 6260168744 ", fg='white', bg='#2c475c').pack()

def block5():
    p11 = LabelFrame(Home, text="Block6", fg='white', bg='#2c475c', font=('arial', 14), padx=19,pady=30)
    p11.place(x=1120, y=305)
    p11.configure(bg='#2c475c')

    p1 = Label(p11)
    p1.pack(anchor=CENTER, pady=30, padx=20)
    p1.configure(bg='#2c475c')
    Label(p1, text="Total Parking slot =30", fg='white', bg='#2c475c').pack()
    Label(p1, text=" Available Slot =13", fg='white', bg='#2c475c').pack()
    Label(p1, text="Help No = 9622243312 ", fg='white', bg='#2c475c').pack()


def vehicle_del():

    Label(Home,text="qwerty").pack(anchor=CENTER)

    fv11 = LabelFrame(Home, text="Fill Vehicle Information", fg='white', bg='#2c475c')
    fv11.place(x=500, y=80)
    fv11.configure(bg='#2c475c')

    fv1 = Label(fv11)
    fv1.pack(anchor=CENTER, pady=50,padx=20)
    fv1.configure(bg='#2c475c')

    lb = Label(fv1, text=" Vehicle Name", font=('arial', 12), fg='white', bg='#2c475c')
    lb.pack()
    e1 = Entry(fv1, width=28,textvariable=VNAME)
    e1.pack()
    lb1 = Label(fv1, text="Vehicle Reg", font=('arial', 12), fg='white', bg='#2c475c')
    lb1.pack()
    e2 = Entry(fv1, width=28,textvariable=VREGNO)
    e2.pack()
    lb2 = Label(fv1, text="Type of Wheeler", font=('arial', 12), fg='white', bg='#2c475c')
    lb2.pack()

    R1 = Radiobutton(fv1, text="2 wheeler", variable=var, value=2,
                     bg='#2c475c')
    R1.pack(anchor=W)

    R2 = Radiobutton(fv1, text="4 wheeler", variable=var, value=4,
                     bg='#2c475c')
    R2.pack(anchor=W)

    R3 = Radiobutton(fv1, text="6 wheeler", variable=var, value=6,bg='#2c475c')
    R3.pack(anchor=W)
    global lbl
    lbl = Label(fv1, bg="#2c475c")
    lbl.pack(anchor=W)


    lb3 = Label(fv1, text="Contact No", font=('arial', 12), fg='white', bg='#2c475c')
    lb3.pack()
    e5 = Entry(fv1, width=28,textvariable=VMOB)
    e5.pack()

    lb3 = Label(fv1, text="Username", font=('arial', 12), fg='white', bg='#2c475c')
    lb3.pack()
    e5 = Entry(fv1, width=28, textvariable=VUSER)
    e5.pack()

    v1 = Button(fv1, text="CANCEL", height=1, width=8, bg="#2c475c", fg="white", command=fv11.destroy)
    v1.pack(side=LEFT, padx=13, pady=10)

    v2 = Button(fv1, text="SUBMIT", height=1, width=8, bg="#2c475c", fg="white",command=v_insert)
    v2.pack(side=LEFT, padx=5)



"""
def sel():
        selection = "You selected  " + str(var.get()) +" wheeler "
        lbl.config(text=selection,fg='white', bg='#2c475c')
"""
def signup_screen():
    print("Successfully signup")
    main.withdraw()
    Home = Toplevel()
    Home.geometry("1366x768")
    Home.configure(bg='#2c475c')
    f1 = Frame(Home, width=1366, height=700, bd=5, relief="flat", bg="white")
    f1.pack(padx=0, pady=70)
    b4 = Button(Home, text="BACK", height=3, width=20, bg="#2c475c", fg="white", command=main.deiconify)
    b4.place(x=1, y=4)



    lb = Label(Home,text=" First Name", font=('arial', 12), bg='white', fg='#2c475c')
    lb.place(x=60, y=120)

    lb1 = Label(Home,text="Last Name", font=('arial', 12), bg='white', fg='#2c475c')
    lb1.place(x=63, y=150)

    lb2 = Label(Home,text="Gender", font=('arial', 12), bg='white', fg='#2c475c')
    lb2.place(x=65, y=180)

    lb3 = Label(Home,text="Age", font=('arial', 12), bg='white', fg='#2c475c')
    lb3.place(x=65, y=210)

    lb4 = Label(Home,text="Address", font=('arial', 12), bg='white', fg='#2c475c')
    lb4.place(x=65, y=240)

    lb5 = Label(Home,text="Aadhar No", font=('arial', 12), bg='white', fg='#2c475c')
    lb5.place(x=65, y=270)

    lb6 = Label(Home,text="Mobile No", font=('arial', 12), bg='white', fg='#2c475c')
    lb6.place(x=65, y=300)

    lb7 = Label(Home,text="Username", font=('arial', 12), bg='white', fg='#2c475c')
    lb7.place(x=65, y=330)

    lb8 = Label(Home,text="Password", font=('arial', 12), bg='white', fg='#2c475c')
    lb8.place(x=65, y=360)



    Male = Radiobutton(Home, text="Male", variable=GENDER, value="Male", bg='white')
    Female = Radiobutton(Home, text="Female", variable=GENDER, value="Female", bg='white')
    Other = Radiobutton(Home, text="Other", variable=GENDER, value="Other", bg='white')

    #--------------------------------

    e1 = Entry(Home, width=28, textvariable=FNAME)
    e1.place(x=160, y=120)

    e2 = Entry(Home,width=28, textvariable=LNAME)
    e2.place(x=160, y=150)

    e4 = Entry(Home, width=28, textvariable=AGE)
    e4.place(x=160, y=210)

    e5 = Entry(Home,width=28, textvariable=ADDRESS)
    e5.place(x=160, y=240)

    e6 = Entry(Home, width=28, textvariable=AADHAR)
    e6.place(x=160, y=270)

    e7 = Entry(Home, width=28, textvariable=MOBILE)
    e7.place(x=160, y=300)

    e8 = Entry(Home, width=28, textvariable=UNAME)
    e8.place(x=160, y=330)

    e9 = Entry(Home, width=28, textvariable=PASS)
    e9.place(x=160, y=360)

    Male.place(x=160, y=180)
    Female.place(x=232, y=180)
    Other.place(x=322, y=180)

    h1 = Button(Home, text="Submit", font=('arial', 12), bg='white', fg='#2c475c', command=dyanamic_insert)
    h1.place(x=180, y=440)

    global result
    result = Label(Home)
    result.place(x=120, y=420)




############################################################

def dyanamic_insert():
    if  FNAME.get() == "" or LNAME.get() == "" or GENDER.get() == "" or AGE.get() == "" or ADDRESS.get() == "" or AADHAR.get() == "" or \
            MOBILE.get() == "" or UNAME.get() == "" or PASS.get() == "":

        result.config(text="Please complete the required field!", fg="red",bg='white')




    else:
        database()
        conn = sqlite3.connect("pm.db")
        cur = conn.cursor()

        cur.execute("INSERT INTO USER (FIRSTNAME,LASTTNAME,GENDER,AGE,ADDRESS,AADHAR_NO,MOBILE_NO,USERNAME,PASSWOARD) \
                   VALUES(?,?,?,?,?,?,?,?,?)", (str(FNAME.get()), str(LNAME.get()), str(GENDER.get()), str(AGE.get()),\
                                                str(ADDRESS.get()), str(AADHAR.get()), str(MOBILE.get()),str(UNAME.get()), str(PASS.get())))
        conn.commit()
        FNAME.set("")
        LNAME.set("")
        GENDER.set("")
        AGE.set("")
        ADDRESS.set("")
        AADHAR.set("")
        MOBILE.set("")
        UNAME.set("")
        PASS.set("")
        cur.close()
        conn.close()
        result.config(text="--------Successfully Account Created!----------", fg="green",bg='white')




#-------------------------Label----------------------



#-------------------------Entry----------------------



#-------------------------Frame-----------------------


f1 = Frame(main, width=1366, height=700, bd=5, relief="flat",bg="white")
f1.pack(padx=0,pady=70)

l1=Label(f1,text="Vehicles Need a Safe ",font=('arial', 28),bg="white",fg="#2c475c")
l1.place(x=60,y=250)

l2=Label(f1,text=" Place to Park.Not Fines!",font=('arial', 28),bg="white",fg="#2c475c")
l2.place(x=60,y=300)


canvas = Canvas(width = 700, height = 180, bg = 'white')
canvas.place(x=600,y=430)
filename = PhotoImage(file = "C:\\Users\\Hp\\Documents\\Python_project\\asg.png")
canvas.create_image(340, 100, image = filename)




#-----------------Button-----------------


b1=Button(main,text="Exit !",height=3,width=20,bg="#2c475c",fg="white",command=main.destroy)
b1.place(x=1177,y=4)

b2=Button(main,text="SIGN IN",height=3,width=20,bg="#2c475c",fg="white",command=login_screen)
b2.place(x=990,y=4)

b3=Button(main,text="CREATE AN ACCOUNT",height=3,width=20,bg="white",command=signup_screen)
b3.place(x=80,y=450)

b4=Button(main,text="ADMIN LOG IN",height=3,width=20,bg="#2c475c",fg="white",command=admin_log_screen)
b4.place(x=810,y=4)







time1 = ''
clock = Label(main, font=('times', 40, 'bold'), fg="#2c475c",bg="white")
clock.place(x=1080,y=300)


def tick():
    global time1
    # get the current local time from the PC
    time2 = time.strftime('%H:%M:%S')
    # if time string has changed, update it
    if time2 != time1:
        time1 = time2
        clock.config(text=time2)
    # calls itself every 200 milliseconds
    # to update the time display as needed
    # could use >200 ms, but display gets jerky
    clock.after(200, tick)


tick()



main.mainloop()

